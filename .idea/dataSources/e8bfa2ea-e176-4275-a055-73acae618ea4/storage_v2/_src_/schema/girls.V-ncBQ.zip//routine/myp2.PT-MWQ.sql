create
    definer = root@localhost procedure myp2(IN beautyName varchar(20))
BEGIN
SELECT bo.*
FROM boys bo
RIGHT JOIN beauty b ON bo.id = b.boyfriend_id
WHERE b.`name` = beautyName;
END;

