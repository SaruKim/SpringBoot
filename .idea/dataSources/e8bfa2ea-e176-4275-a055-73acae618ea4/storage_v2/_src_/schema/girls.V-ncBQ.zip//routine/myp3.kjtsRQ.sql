create
    definer = root@localhost procedure myp3(IN username varchar(20), IN PASSWORD varchar(20))
BEGIN
DECLARE result VARCHAR(20) DEFAULT '';
SELECT COUNT(*) INTO result
FROM admin
WHERE admin.username = username
AND admin.`password` = `password`;
SELECT result;

END;

