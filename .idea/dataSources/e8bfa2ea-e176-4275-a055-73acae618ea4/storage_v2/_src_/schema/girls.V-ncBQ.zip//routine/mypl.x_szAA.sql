create
    definer = root@localhost procedure mypl()
BEGIN
INSERT INTO admin(username,`password`) 
VALUES
('john1','0000'),
('lily','1111'),
('jack','2222'),
('rose','3333'),
('tom','4444');
END;

