create
    definer = root@localhost procedure pro_while1(IN insertCount int)
BEGIN
DECLARE i INT DEFAULT 1;
a:WHILE i <= insertCount
DO
INSERT INTO admin(username,`password`)
VALUES(CONCAT('rose',i),'666');
SET i = i + 1;
END WHILE a;
END;

