create
    definer = root@localhost procedure test_pro1(IN username varchar(20), IN loginPwd varchar(20))
BEGIN
INSERT INTO admin(admin.username,`password`)
VALUES(username,loginpwd);
END;

