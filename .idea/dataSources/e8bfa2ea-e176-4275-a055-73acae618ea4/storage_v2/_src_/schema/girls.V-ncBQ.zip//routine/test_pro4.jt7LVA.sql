create
    definer = root@localhost procedure test_pro4(IN mydate datetime, OUT strDate varchar(50))
BEGIN
	SELECT DATE_FORMAT(mydate,'%y年%m月%d日') INTO strDate;

END;

