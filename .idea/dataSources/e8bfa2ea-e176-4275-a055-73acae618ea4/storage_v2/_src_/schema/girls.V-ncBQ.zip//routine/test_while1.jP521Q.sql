create
    definer = root@localhost procedure test_while1(IN insertCount int)
BEGIN
DECLARE i INT DEFAULT 1;
a:WHILE i<= insertCount
DO
INSERT INTO admin(username,`password`)
VALUES(CONCAT('rose',i),'7777');
IF i >= 20 THEN LEAVE a;
END IF;
SET i = i + 1;
END WHILE a;
END;

