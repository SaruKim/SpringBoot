create
    definer = root@localhost procedure test_while2(IN insertCount int)
BEGIN
	DECLARE i INT DEFAULT 0;
	a:WHILE i<= insertCount
	DO
	SET i = i + 1;
	IF i % 2 <> 0 THEN ITERATE a;
	END IF;
	INSERT INTO admin(username,`password`)
	VALUES(CONCAT('rose',i),'7777');
	END WHILE a;
END;

