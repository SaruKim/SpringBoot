create
    definer = root@localhost function myf2(empName varchar(20)) returns double
BEGIN
SET @sal = 0;
SELECT salary INTO @sal
FROM employees
WHERE last_name = empName;
RETURN @sal;
END;

