create definer = root@localhost view v1 as
select `s`.`stuName` AS `stuname`, `m`.`majorName` AS `majorname`
from (`students`.`stuinfo` `s`
         join `students`.`major` `m` on ((`s`.`majorId` = `m`.`id`)));

